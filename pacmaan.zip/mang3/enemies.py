#!/usr/bin/env python
# -*- coding: utf-8 -*-

import pygame  # Impordi pygame moodul mängu arendamiseks
import random  # Impordi random moodul juhuslike numbrite genereerimiseks

# Konstandid ekraani mõõtmete jaoks
SCREEN_WIDTH = 800  # Ekraani laius
SCREEN_HEIGHT = 576  # Ekraani kõrgus

# Määra mõned värvid kasutades RGB tupleid
BLACK = (0,0,0)  # Must värv
WHITE = (255,255,255)  # Valge värv
BLUE = (0,0,255)  # Sinine värv
GREEN = (0,255,0)  # Roheline värv
RED = (255,0,0)  # Punane värv

# Defineeri klass Block, mis pärib pygame Sprite klassist
class Block(pygame.sprite.Sprite):
    def __init__(self, x, y, color, width, height):
        # Kutsu välja vanemklassi (Sprite) konstruktor
        pygame.sprite.Sprite.__init__(self)
        # Loo Surface objekt ploki jaoks ja täida see määratud värviga
        self.image = pygame.Surface([width, height])
        self.image.fill(color)
        # Saa ristkülik, mis ümbritseb pinda
        self.rect = self.image.get_rect()
        # Sea ristküliku ülemine vasak nurk määratud koordinaatidele
        self.rect.topleft = (x, y)  # Määratud koordinaadid

# Defineeri klass Ellipse, mis pärib pygame Sprite klassist
class Ellipse(pygame.sprite.Sprite):
    def __init__(self, x, y, color, width, height):
        # Kutsu välja vanemklassi (Sprite) konstruktor
        pygame.sprite.Sprite.__init__(self)
        # Loo Surface objekt ellipsi jaoks ja täida see musta värviga
        self.image = pygame.Surface([width, height])
        self.image.fill(BLACK)
        # Sea värv läbipaistvaks
        self.image.set_colorkey(BLACK)
        # Joonista ellips
        pygame.draw.ellipse(self.image, color, [0, 0, width, height])
        # Saa ristkülik, mis ümbritseb pinda
        self.rect = self.image.get_rect()
        # Sea ristküliku ülemine vasak nurk määratud koordinaatidele
        self.rect.topleft = (x, y)  # Määratud koordinaadid

# Defineeri klass Slime, mis pärib pygame Sprite klassist
class Slime(pygame.sprite.Sprite):
    def __init__(self, x, y, change_x, change_y, image_file, width=32, height=32):
        # Kutsu välja vanemklassi (Sprite) konstruktor
        pygame.sprite.Sprite.__init__(self)
        # Määra horisontaalne muutus
        self.change_x = change_x
        # Määra vertikaalne muutus
        self.change_y = change_y
        # Laadi pildifail ja tee see läbipaistvaks
        self.image = pygame.image.load(image_file).convert_alpha()
        # Muuda pildi suurust
        self.image = pygame.transform.scale(self.image, (width, height))
        # Saa ristkülik, mis ümbritseb pinda
        self.rect = self.image.get_rect()
        # Sea ristküliku ülemine vasak nurk määratud koordinaatidele
        self.rect.topleft = (x, y)  # Määratud koordinaadid

    def update(self, horizontal_blocks, vertical_blocks):
        # Liiguta lima horisontaalselt
        self.rect.x += self.change_x
        # Liiguta lima vertikaalselt
        self.rect.y += self.change_y
        # Kui lima liigub ekraanilt vasakule, ilmub see paremal
        if self.rect.right < 0:
            self.rect.left = SCREEN_WIDTH
        # Kui lima liigub ekraanilt paremale, ilmub see vasakul
        elif self.rect.left > SCREEN_WIDTH:
            self.rect.right = 0
        # Kui lima liigub ekraanilt üles, ilmub see all
        if self.rect.bottom < 0:
            self.rect.top = SCREEN_HEIGHT
        # Kui lima liigub ekraanilt alla, ilmub see üleval
        elif self.rect.top > SCREEN_HEIGHT:
            self.rect.bottom = 0

        # Kui lima jõuab ristumiskohta, valib juhuslikult uue suuna
        if self.rect.topleft in self.get_intersection_position():
            direction = random.choice(("left", "right", "up", "down"))
            if direction == "left" and self.change_x == 0:
                self.change_x = -2
                self.change_y = 0
            elif direction == "right" and self.change_x == 0:
                self.change_x = 2
                self.change_y = 0
            elif direction == "up" and self.change_y == 0:
                self.change_x = 0
                self.change_y = -2
            elif direction == "down" and self.change_y == 0:
                self.change_x = 0
                self.change_y = 2

    def get_intersection_position(self):
        # Loetleb kõik ristumiskohad
        items = []
        for i, row in enumerate(enviroment()):
            for j, item in enumerate(row):
                if item == 3:
                    items.append((j * 32, i * 32))
        # Tagastab ristumiskohtade nimekirja
        return items

# Määratleb mängukeskkonna
def enviroment():
    # Loob ruudustiku mänguväljaks
    grid = ((0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0),
            (0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0),
            (1,3,1,1,1,1,1,1,1,3,1,1,1,1,1,1,1,3,1,1,1,1,1,3,1),
            (0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0),
            (0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0),
            (0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0),
            (1,3,1,1,1,1,1,1,1,3,1,1,1,1,1,1,1,3,1,1,1,1,1,3,1),
            (0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0),
            (0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0),
            (0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0),
            (1,3,1,1,1,1,1,1,1,3,1,1,1,1,1,1,1,3,1,1,1,1,1,3,1),
            (0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0),
            (0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0),
            (0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0),
            (1,3,1,1,1,1,1,1,1,3,1,1,1,1,1,1,1,3,1,1,1,1,1,3,1),
            (0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0),
            (0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0),
            (0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0))
    # Tagastab ruudustiku
    return grid

# Joonistab mängukeskkonna ekraanile
def draw_enviroment(screen):
    for i, row in enumerate(enviroment()):
        for j, item in enumerate(row):
            if item == 1:
                pygame.draw.line(screen, BLUE, [j*32, i*32], [j*32+32, i*32], 3)
                pygame.draw.line(screen, BLUE, [j*32, i*32+32], [j*32+32, i*32+32], 3)
            elif item == 2:
                pygame.draw.line(screen, BLUE, [j*32, i*32], [j*32, i*32+32], 3)
                pygame.draw.line(screen, BLUE, [j*32+32, i*32], [j*32+32, i*32+32], 3)