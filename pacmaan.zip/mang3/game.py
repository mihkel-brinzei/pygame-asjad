#!/usr/bin/env python
# -*- coding: utf-8 -*-

import pygame  # Impordi pygame moodul mängu arendamiseks
from player import Player  # Impordi Player klass mängija jaoks
from enemies import *  # Impordi kõik elemendid enemies moodulist
import tkinter  # Impordi tkinter moodul dialoogikastide jaoks
from tkinter import messagebox  # Impordi messagebox moodul dialoogikastide jaoks

# Konstandid ekraani mõõtmete jaoks
SCREEN_WIDTH = 800  # Ekraani laius
SCREEN_HEIGHT = 576  # Ekraani kõrgus

# Määra mõned värvid kasutades RGB tupleid
BLACK = (0, 0, 0)  # Must värv
WHITE = (255, 255, 255)  # Valge värv
BLUE = (0, 0, 255)  # Sinine värv
RED = (255, 0, 0)  # Punane värv

# Defineeri klass Game, mis haldab mängu loogikat ja olekut
class Game(object):
    def __init__(self):
        self.font = pygame.font.Font(None, 40)  # Loo font objekt
        self.about = False  # Muutuja about režiimi jälgimiseks
        self.game_over = True  # Muutuja mängu lõpu seisundi jälgimiseks
        self.score = 0  # Mängija skoor
        self.font = pygame.font.Font(None, 35)  # Loo uus font objekt
        self.menu = Menu(("Start", "About", "Exit"), font_color=WHITE, font_size=60)  # Loo menüü
        self.player = Player(32, 128, "player.png")  # Loo mängija
        self.horizontal_blocks = pygame.sprite.Group()  # Loo grupp horisontaalsete plokkide jaoks
        self.vertical_blocks = pygame.sprite.Group()  # Loo grupp vertikaalsete plokkide jaoks
        self.dots_group = pygame.sprite.Group()  # Loo grupp täppide jaoks

        # Loo plokid vastavalt keskkonnale
        for i, row in enumerate(enviroment()):
            for j, item in enumerate(row):
                if item == 1:
                    self.horizontal_blocks.add(Block(j * 32 + 8, i * 32 + 8, BLACK, 16, 16))
                elif item == 2:
                    self.vertical_blocks.add(Block(j * 32 + 8, i * 32 + 8, BLACK, 16, 16))

        self.enemies = pygame.sprite.Group()  # Loo grupp vaenlaste jaoks
        enemy_images = ["slime.png", "slime2.png", "slime3.png"]  # Vaenlaste pildid
        enemy_positions = [  # Vaenlaste positsioonid ja liikumisvektorid
            (288, 96, 0, 2),
            (288, 320, 0, -2),
            (544, 128, 0, 2),
            (32, 224, 0, 2),
            (160, 64, 2, 0),
            (448, 64, -2, 0),
            (640, 448, 2, 0),
            (448, 320, 2, 0)
        ]

        # Loo vaenlased ja lisa need gruppi
        for pos in enemy_positions:
            image_file = random.choice(enemy_images)
            self.enemies.add(Slime(pos[0], pos[1], pos[2], pos[3], image_file))

        # Loo täpid vastavalt keskkonnale
        for i, row in enumerate(enviroment()):
            for j, item in enumerate(row):
                if item != 0:
                    self.dots_group.add(Ellipse(j * 32 + 12, i * 32 + 12, WHITE, 8, 8))

        # Laadi helifailid
        self.pacman_sound = pygame.mixer.Sound("pacman_sound.ogg")
        self.game_over_sound = pygame.mixer.Sound("game_over_sound.ogg")

    def process_events(self):
        # Käitle kasutaja sündmusi
        for event in pygame.event.get():  # Kasutaja tegi midagi
            if event.type == pygame.QUIT:  # Kui kasutaja klõpsas sulgemist
                return True
            self.menu.event_handler(event)  # Käitle menüü sündmusi
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    if self.game_over and not self.about:
                        if self.menu.state == 0:
                            # ---- ALUSTA ------
                            self.__init__()
                            self.game_over = False
                        elif self.menu.state == 1:
                            # --- INFO ------
                            self.about = True
                        elif self.menu.state == 2:
                            # --- VÄLJU -------
                            # Kasutaja klõpsas väljumist
                            return True

                elif event.key == pygame.K_RIGHT:
                    self.player.move_right()

                elif event.key == pygame.K_LEFT:
                    self.player.move_left()

                elif event.key == pygame.K_UP:
                    self.player.move_up()

                elif event.key == pygame.K_DOWN:
                    self.player.move_down()

                elif event.key == pygame.K_ESCAPE:
                    self.game_over = True
                    self.about = False

            elif event.type == pygame.KEYUP:
                if event.key == pygame.K_RIGHT:
                    self.player.stop_move_right()
                elif event.key == pygame.K_LEFT:
                    self.player.stop_move_left()
                elif event.key == pygame.K_UP:
                    self.player.stop_move_up()
                elif event.key == pygame.K_DOWN:
                    self.player.stop_move_down()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                self.player.explosion = True

        return False

    def run_logic(self):
        # Käivita mängu loogika
        if not self.game_over:
            self.player.update(self.horizontal_blocks, self.vertical_blocks)
            block_hit_list = pygame.sprite.spritecollide(self.player, self.dots_group, True)
            # Kui block_hit_list sisaldab ühte sprite'i, tähendab see, et mängija tabas täppi
            if len(block_hit_list) > 0:
                # Siin toimub heliefekt
                self.pacman_sound.play()
                self.score += 1
            block_hit_list = pygame.sprite.spritecollide(self.player, self.enemies, True)
            if len(block_hit_list) > 0:
                self.player.explosion = True
                self.game_over_sound.play()
            self.game_over = self.player.game_over
            self.enemies.update(self.horizontal_blocks, self.vertical_blocks)
            # tkMessageBox.showinfo("MÄNG LÄBI!", "Lõplik skoor = " + (str)(GAME.score))

    def display_frame(self, screen):
        # Kõigepealt tühjenda ekraan mustaks
        screen.fill(BLACK)
        # --- Joonistamise kood peaks olema siin
        if self.game_over:
            if self.about:
                self.display_message(screen, "See on arkaadmäng")
                # "labürint, mis sisaldab erinevaid täppe,\n"
                # "tuntud kui Pac-Dots, ja neli kummitust.\n"
                # "Neli kummitust rändavad labürindis, üritades Pac-Mani tappa.\n"
                # "Kui mõni kummitus tabab Pac-Mani, kaotab ta elu;\n"
                # "mäng on läbi.\n")
            else:
                self.menu.display_frame(screen)
        else:
            # --- Joonista mäng siin ---
            self.horizontal_blocks.draw(screen)
            self.vertical_blocks.draw(screen)
            draw_enviroment(screen)
            self.dots_group.draw(screen)
            self.enemies.draw(screen)
            screen.blit(self.player.image, self.player.rect)
            # text=self.font.render("Skoor: " + (str)(self.score), 1, self.RED)
            # screen.blit(text, (30, 650))
            # Renderda tekst skoori jaoks
            text = self.font.render("Skoor: " + str(self.score), True, GREEN)
            # Aseta tekst ekraanile
            screen.blit(text, [120, 20])

        # --- Uuenda ekraan sellega, mis on joonistatud
        pygame.display.flip()

    def display_message(self, screen, message, color=(255, 0, 0)):
        # Kuvab sõnumi ekraanil
        label = self.font.render(message, True, color)
        # Saa sildi laius ja kõrgus
        width = label.get_width()
        height = label.get_height()
        # Määra sildi positsioon
        posX = (SCREEN_WIDTH / 2) - (width / 2)
        posY = (SCREEN_HEIGHT / 2) - (height / 2)
        # Joonista silt ekraanile
        screen.blit(label, (posX, posY))

# Defineeri klass Menu, mis haldab menüü loogikat ja kuvamist
class Menu(object):
    state = 0  # Menüü algseisund
    def __init__(self, items, font_color=(0, 0, 0), select_color=(255, 0, 0), ttf_font=None, font_size=25):
        self.font_color = font_color  # Fondi värv
        self.select_color = select_color  # Valitud üksuse värv
        self.items = items  # Menüü üksused
        self.font = pygame.font.Font(ttf_font, font_size)  # Loo font objekt

    def display_frame(self, screen):
        # Kuvab menüü ekraanil
        for index, item in enumerate(self.items):
            if self.state == index:
                label = self.font.render(item, True, self.select_color)
            else:
                label = self.font.render(item, True, self.font_color)

            width = label.get_width()
            height = label.get_height()

            posX = (SCREEN_WIDTH / 2) - (width / 2)
            # t_h: teksti ploki kogukõrgus
            t_h = len(self.items) * height
            posY = (SCREEN_HEIGHT / 2) - (t_h / 2) + (index * height)

            screen.blit(label, (posX, posY))

    def event_handler(self, event):
        # Käitleb menüü sündmusi
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                if self.state > 0:
                    self.state -= 1
            elif event.key == pygame.K_DOWN:
                if self.state < len(self.items) - 1:
                    self.state += 1