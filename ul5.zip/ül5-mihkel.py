# Mihkel Brinzei
import pygame
import random

pygame.init()

# akna seaded
screen_width = 640
screen_height = 480
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Ping-pong")

# pildid ja taust
alus = pygame.transform.scale(pygame.image.load('pad.png'), (120, 20))
ball = pygame.transform.scale(pygame.image.load('ball.png'), (20, 20))
background_color = (204, 255, 255)

# alused
base_width = 120
base_height = 20
base_y = int(screen_height / 1.5)
base_speed = 1
base_x = (screen_width - base_width) // 2

# palli settingud
ball_size = 20
ball_x = random.randint(0, screen_width - ball_size)
ball_y = random.randint(50, 150)
ball_speed_x = 3 * random.choice([-1, 1])
ball_speed_y = 3

# skoori asjad
score = 0
font = pygame.font.Font(None, 36)
text_color = (255, 0, 0)

# loop
running = True
clock = pygame.time.Clock()

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # aluse liikumine
    base_x += base_speed    
    # aluse ümberpööramine
    if base_x <= 0 or base_x >= screen_width - base_width:
        base_speed = -base_speed

    # palli kiirus
    ball_x += ball_speed_x
    ball_y += ball_speed_y

    # põrkab seinadelt
    if ball_x <= 0 or ball_x >= screen_width - ball_size:
        ball_speed_x = -ball_speed_x
    if ball_y <= 0:
        ball_speed_y = -ball_speed_y

    # kokkupõrge alusega 
    if (ball_y + ball_size >= base_y and
        ball_y + ball_size <= base_y + base_height and
        ball_x + ball_size >= base_x and
        ball_x <= base_x + base_width):
        if ball_speed_y > 0:  # kontroll kas pall liigub
            ball_speed_y = -ball_speed_y
            score += 1
            print(score)
    # kontroll kas pall läheb aluse pihta
    elif ball_y > screen_height:
        if ball_x <= 0 or ball_x >= screen_width - ball_size:
            ball_speed_x = -ball_speed_x
        ball_speed_y = -ball_speed_y
        score -= 1  # 1 skoor maha kui akna alusega puutub
        print(score)

    # näitab palli ja asukohta
    screen.fill(background_color)
    screen.blit(alus, (base_x, base_y))
    screen.blit(ball, (ball_x, ball_y))
    
    # scorei näitamine
    score_text = font.render(f'Skoor: {score}', True, text_color)
    screen.blit(score_text, (10, 10))

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
