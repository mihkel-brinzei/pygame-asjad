# Mihkel Brinzei

import pygame
import sys
import random

pygame.init()

# ekraani seaded
screenX = 640
screenY = 480
screen = pygame.display.set_mode([screenX, screenY])
pygame.display.set_caption("Animeerimine - Mihkel")

# lae taustapilt ja autode pildid
bg = pygame.image.load("bg_rally.jpg")
auto1 = pygame.image.load("f1_red.png")
auto2 = pygame.image.load("f1_blue.png")
auto2 = pygame.transform.rotate(auto2, 180)  # punase auto pööramine

# koordinaadid autodel punane a1 sinine a2
auto1_x, auto1_y = 300, 390  # Punase auto asukoht
speedY = random.randint(1, 15)  # Sinise auto kiirus suvaline
car_data = [
    {"x": 170, "start_y": random.randint(-screenY, -auto2.get_height())},  #auto alguskohad
    {"x": 430, "start_y": random.randint(-screenY, -auto2.get_height())}  
]

# mängu muutujad
score = 0
tekst = pygame.font.Font(None, 36)  # Font teksti kuvamiseks

clock = pygame.time.Clock()

game_over = False
while not game_over:
    clock.tick(60)  # fps

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            game_over = True

    # tühjenda ekraan ja joonista taustapilt
    screen.blit(bg, [0, 0])
    screen.blit(auto1, [auto1_x, auto1_y])

    # liiguta autosid
    for car in car_data:
        screen.blit(auto2, [car["x"], car["start_y"]])  # tekita auto coordi kohtades
        car["start_y"] += speedY  # auto kiirus lõpuks

        if car["start_y"] > screenY:
            car["start_y"] = random.randint(-screenY, -auto2.get_height())  # auto liigub ülesse tagasi
            score += 1  # auto lõppu jõuab saab skoori juurde

    # skoor
    score_text = tekst.render(f"Skoor: {score}", True, (255, 0, 255))
    screen.blit(score_text, (10, 10))

    pygame.display.flip()

pygame.quit()
sys.exit()

