# Snake Eater
# Programm, mis loob Snake mängu kasutades PyGame'i
# Lisandused Mihkel Brinzei

# NB!!! Soovitan mängu vaiksema häälega mängida!!!! Olete hoiatatud!

import pygame, sys, time, random

# Raskusastmed
# Lihtne      ->  10
# Keskmine    ->  25
# Raske      ->  40
# Raskem    ->  60
# Võimatu->  120
difficulty = 25  # 

# Akna suurus
frame_size_x = 720  # Akna laius
frame_size_y = 480  # Akna kõrgus

# Tekitab mängu
check_errors = pygame.init()  # Kontrolli, kas pygame on õigesti initsialiseeritud
if check_errors[1] > 0:
    print(f'[!] Had {check_errors[1]} errors when initialising game, exiting...')
    sys.exit(-1)  # Väljundi ja veakoodiga väljumine
else:
    print('[+] Game successfully initialised')  # Kinnituskiri, et mäng on edukalt initsialiseeritud

# Alustab muusika funktsioonid
pygame.mixer.init()  # Initsialiseeri helimikser

# laeb ja mängib muusikat
pygame.mixer.music.load('2AM.mp3')  # Lae taustamuusika
pygame.mixer.music.play(-1)  # -1 tähendab lõpmatu kordamist

# laeb hääle effekti
food_sound = pygame.mixer.Sound('bell.mp3')  # Lae heliefekt toidu võtmiseks

# akna tekitamine
pygame.display.set_caption('Snake Game - Mihkel Brinzei')  # Pane pealkiri aknale
game_window = pygame.display.set_mode((frame_size_x, frame_size_y))  # Määra akna suurus

# värvid
black = pygame.Color(0, 0, 0)  # Must värv
white = pygame.Color(255, 255, 255)  # Valge värv
red = pygame.Color(255, 0, 0)  # Punane värv
green = pygame.Color(0, 255, 0)  # Roheline värv
blue = pygame.Color(0, 0, 255)  # Sinine värv

# FPS
fps_controller = pygame.time.Clock()  # Loome mängu raamistiku kontrolleri

# mängu väärtused
snake_pos = [100, 50]  # Ussi alguspositsioon
snake_body = [[100, 50], [100-10, 50], [100-(2*10), 50]]  # Ussi keha algus

food_pos = [random.randrange(1, (frame_size_x//30)) * 30, random.randrange(1, (frame_size_y//30)) * 30]  # Toitu positsioon
food_spawn = True  # Kas toit on alles?

# banaani väärtused
banana_pos = [random.randrange(1, (frame_size_x//30)) * 30, random.randrange(1, (frame_size_y//30)) * 30]  # Banaani positsioon
banana_spawn = False  # Kas banaan on alles?
banana_chance = 1  # % chance of spawning a banana each frame

direction = 'RIGHT'  # Algus suund
change_to = direction  # Suuna muutmine

score = 0  # Skoor

# laeb toidu pildid
food_image = pygame.image.load('oun.png')  # Lae toidu pilt
food_image = pygame.transform.scale(food_image, (30, 30))  # Muuda pildi suurust

banana_image = pygame.image.load('ban.png')  # Lae banaani pilt
banana_image = pygame.transform.scale(banana_image, (30, 30))  # Muuda pildi suurust

# mäng läbi funktsioonid
def game_over():
    my_font = pygame.font.SysFont('times new roman', 90)  # Vali font ja suurus
    game_over_surface = my_font.render('YOU DIED', True, red)  # Loo pind tekstiga "YOU DIED"
    game_over_rect = game_over_surface.get_rect()  # Võta teksti piirid
    game_over_rect.midtop = (frame_size_x/2, frame_size_y/4)  # Määra teksti asukoht
    game_window.fill(black)  # Täida akent mustaga
    game_window.blit(game_over_surface, game_over_rect)  # Kuvada teksti pind aknal
    show_score(0, red, 'times', 20)  # Näita skoori
    pygame.display.flip()  # Värskenda ekraani
    time.sleep(3)  # Oota 3 sekundit
    pygame.quit()  # Lõpeta pygame
    sys.exit()  # Välju

# skoor
def show_score(choice, color, font, size):
    score_font = pygame.font.SysFont(font, size)  # Vali font ja suurus
    score_surface = score_font.render('Score : ' + str(score), True, color)  # Loo skoori pind
    score_rect = score_surface.get_rect()  # Võta skoori piirid
    if choice == 1:
        score_rect.midtop = (frame_size_x/10, 15)  # Määra skoori asukoht
    else:
        score_rect.midtop = (frame_size_x/2, frame_size_y/1.25)  # Määra skoori asukoht
    game_window.blit(score_surface, score_rect)  # Kuvada skoori pind aknal

# pea loogika
while True:  # Mängu peamine tsükkel
    for event in pygame.event.get():  # Võta pygame'i sündmused
        if event.type == pygame.QUIT:  # Kui kasutaja vajutab ristile
            pygame.quit()  # Lõpeta pygame
            sys.exit()  # Välju
        elif event.type == pygame.KEYDOWN:  # Kui kasutaja vajutab klaviatuuri klahvi
            if event.key == pygame.K_UP or event.key == ord('w'):
                change_to = 'UP'  # Muuda suunda üles
            if event.key == pygame.K_DOWN or event.key == ord('s'):
                change_to = 'DOWN'  # Muuda suunda alla
                    # Kontrolli, kas kasutaja vajutab vasakut noolt või 'a' klahvi
            if event.key == pygame.K_LEFT or event.key == ord('a'):
                change_to = 'LEFT'  # Muuda ussi suunda vasakule
        # Kontrolli, kas kasutaja vajutab paremat noolt või 'd' klahvi
            if event.key == pygame.K_RIGHT or event.key == ord('d'):
                change_to = 'RIGHT'  # Muuda ussi suunda paremale
        # Kontrolli, kas kasutaja vajutab 'ESC' klahvi
            if event.key == pygame.K_ESCAPE:
                pygame.event.post(pygame.event.Event(pygame.QUIT))  # Saada pygame sündmus väljumiseks

    # Ussi suuna muutmine vastavalt kasutaja sisendile
    if change_to == 'UP' and direction != 'DOWN':
        direction = 'UP'  # Muuda suunda üles, kui praegune suund pole alla
    if change_to == 'DOWN' and direction != 'UP':
        direction = 'DOWN'  # Muuda suunda alla, kui praegune suund pole üles
    if change_to == 'LEFT' and direction != 'RIGHT':
        direction = 'LEFT'  # Muuda suunda vasakule, kui praegune suund pole paremale
    if change_to == 'RIGHT' and direction != 'LEFT':
        direction = 'RIGHT'  # Muuda suunda paremale, kui praegune suund pole vasakule

    # Ussi uue positsiooni arvutamine vastavalt suunale
    if direction == 'UP':
        snake_pos[1] -= 10  # Liiguta ussi üles
    if direction == 'DOWN':
        snake_pos[1] += 10  # Liiguta ussi alla
    if direction == 'LEFT':
        snake_pos[0] -= 10  # Liiguta ussi vasakule
    if direction == 'RIGHT':
        snake_pos[0] += 10  # Liiguta ussi paremale

    snake_body.insert(0, list(snake_pos))  # Lisa uus pea ussi keha esimeseks osaks

    # Kontrolli, kas uss sõi toitu või banaani
    if (snake_pos[0] in range(food_pos[0], food_pos[0] + 30)) and (snake_pos[1] in range(food_pos[1], food_pos[1] + 30)):
        score += 1  # Suurenda skoori ühe võrra
        food_spawn = False  # Märgi, et toit on söödud
        food_sound.play()  # Mängi heliefekti
    elif (snake_pos[0] in range(banana_pos[0], banana_pos[0] + 30)) and (snake_pos[1] in range(banana_pos[1], banana_pos[1] + 30)):
        score += 5  # Suurenda skoori viie võrra
        banana_spawn = False  # Märgi, et banaan on söödud
        food_sound.play()  # Mängi heliefekti
    else:
        snake_body.pop()  # Eemalda ussi sabast viimane osa

    # Genereeri uus toidu positsioon, kui toit on söödud
    if not food_spawn:
        food_pos = [random.randrange(1, (frame_size_x//30)) * 30, random.randrange(1, (frame_size_y//30)) * 30]
        food_spawn = True  # Märgi, et toit on uuesti ilmunud

    # Genereeri banaani positsioon juhul, kui banaan pole veel ilmunud ja juhuslik number on väiksem või võrdne banaani tõenäosusega
    if not banana_spawn and random.randint(1, 100) <= banana_chance:
        banana_pos = [random.randrange(1, (frame_size_x//30)) * 30, random.randrange(1, (frame_size_y//30)) * 30]
        banana_spawn = True  # Märgi, et banaan on ilmunud

    # Täida mänguaken mustaga
    game_window.fill(black)
    # Joonista ussi keha
    for pos in snake_body:
        pygame.draw.rect(game_window, green, pygame.Rect(pos[0], pos[1], 10, 10))
    # Kuvada toit
    game_window.blit(food_image, (food_pos[0], food_pos[1]))
    # Kuvada banaan, kui see on ilmunud
    if banana_spawn:
        game_window.blit(banana_image, (banana_pos[0], banana_pos[1]))

    # Kontrolli, kas uss on aknast väljas
    if snake_pos[0] < 0 or snake_pos[0] > frame_size_x-10:
        game_over()  # Kutsu välja mängu lõpp
    if snake_pos[1] < 0 or snake_pos[1] > frame_size_y-10:
        game_over()  # Kutsu välja mängu lõpp
    # Kontrolli, kas uss põrkas kokku iseendaga
    for block in snake_body[1:]:
        if snake_pos[0] == block[0] and snake_pos[1] == block[1]:
            game_over()  # Kutsu välja mängu lõpp

    # Näita skoori akna ülaosas
    show_score(1, white, 'consolas', 20)
    pygame.display.update()  # Värskenda ekraani
    fps_controller.tick(difficulty)  # Määra raamistiku kiirus
