# Mihkel Brinzei
import pygame
import random

pygame.init()

#muusika
pygame.mixer.music.load('muusika.wav')
pygame.mixer.music.play(-1)

# akna seaded
screen_width = 640
screen_height = 480
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Ping-pong")

# pildid ja taust
alus = pygame.transform.scale(pygame.image.load('pad.png'), (120, 20))
ball = pygame.transform.scale(pygame.image.load('ball.png'), (20, 20))
background_color = (204, 255, 255)

# alused
base_width = 120
base_height = 20
base_y = int(screen_height / 1.5)
base_speed = 5  # Adjusted speed for manual control
base_x = (screen_width - base_width) // 2

# palli settingud
ball_size = 20
ball_x = random.randint(0, screen_width - ball_size)
ball_y = random.randint(50, 150)
ball_speed_x = 3 * random.choice([-1, 1])
ball_speed_y = 3

# skoori asjad
score = 0
font = pygame.font.Font(None, 36)
text_color = (255, 0, 0)

# loop
running = True
clock = pygame.time.Clock()

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # võtmed
    keys = pygame.key.get_pressed()
    if keys[pygame.K_a] and base_x > 0:
        base_x -= base_speed
    if keys[pygame.K_d] and base_x < screen_width - base_width:
        base_x += base_speed

    # palli kiirus
    ball_x += ball_speed_x
    ball_y += ball_speed_y

    # põrkab seinadelt
    if ball_x <= 0 or ball_x >= screen_width - ball_size:
        ball_speed_x = -ball_speed_x
    if ball_y <= 0:
        ball_speed_y = -ball_speed_y

    # kokkupõrge alusega 
    if (ball_y + ball_size >= base_y and
        ball_y + ball_size <= base_y + base_height and
        ball_x + ball_size >= base_x and
        ball_x <= base_x + base_width):
        if ball_speed_y > 0:  # kontroll kas pall liigub
            ball_speed_y = -ball_speed_y
            score += 1
            print(score)
    # kontroll kas pall läheb alusest mööda
    elif ball_y > screen_height:
        running = False  # lõpetab kui pall puudutab alumist äärt

    # näitab palli ja asukohta
    screen.fill(background_color)
    screen.blit(alus, (base_x, base_y))
    screen.blit(ball, (ball_x, ball_y))
    
    pygame.display.flip()
    clock.tick(60)

# mängu lõpetamine
screen.fill(background_color)
score_text = font.render(f'Sinu skoor: {score}', True, text_color)
screen.blit(score_text, (screen_width // 2 - score_text.get_width() // 2, screen_height // 2 - score_text.get_height() // 2))
pygame.display.flip()
pygame.time.wait(10000) # ootab 10 sekundit enne kinni panemist

pygame.quit()

