# Mihkel Brinzei
import pygame

pygame.init()
#ekraani seaded
screen=pygame.display.set_mode([640,480])
pygame.display.set_caption("Harjutamine")
screen.fill([204, 255, 204])

#Lisame pildid
bg = pygame.image.load("bg.png") #impordib pildi faili
bg = pygame.transform.scale(bg, [640, 480]) # muudab pildi dimensioone
screen.blit(bg,[0,0]) # lõpuks näitab ekraanil pilti

youWin = pygame.image.load("win.png") # impordib pildi faili
youWin = pygame.transform.scale(youWin, [300, 300]) # muudab pildi dimensioone
screen.blit(youWin,[180,100]) # näitab ekraanil

pygame.display.flip() # Uuendab ekraani, et näidata joonistust

running = True
while running:
    for event in pygame.event.get():
        if event.type ==  pygame.QUIT:
            pygame.quit() # sulgeb akna kui vajutada ristist