import pygame, sys
# Mihkel Brinzei
pygame.init()
 
 
#ekraani seaded
screenX = 640
screenY = 480
screen=pygame.display.set_mode([screenX,screenY])
pygame.display.set_caption("Animeerimine - Mihkel")
bg = pygame.image.load("bg_rally.jpg")
screen.blit(bg,[0,0])
clock = pygame.time.Clock()


#punane auto keskel
auto1 = pygame.image.load("f1_red.png")
screen.blit(auto1,[300,390])
#sinine auto
auto2 = pygame.image.load("f1_blue.png")
auto2 = pygame.transform.rotate(auto2, 180)


#tee koordinaadid
coords = [170, 300, 430]
y = 10

game_over = False
while not game_over:
    clock.tick(60) #fps

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            game_over = True

    #loendist koordinaadid
    for i in range(len(coords)):
        screen.blit(auto2,[coords[i], y])



    pygame.display.flip()   
pygame.quit()
sys.exit()
