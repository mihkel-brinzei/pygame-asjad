#!/usr/bin/env python
# -*- coding: utf-8 -*-

import pygame  # Impordime pygame'i mängumootori
from player import Player  # Impordime Player klassi mängija jaoks
from enemies import *  # Impordime kõik vaenlaste moodulid
import tkinter  # Impordime tkinter'i kasutajaliidese jaoks
from tkinter import messagebox  # Impordime messagebox'i tkinterist
import os  # Impordime operatsioonisüsteemi mooduli
import random  # Impordime random mooduli

# Konstandid ekraani mõõtmete jaoks
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 576

# Värvid RGB-tupleid kasutades
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)

# Mängu klass
class Game(object):
    def __init__(self):
        self.font = pygame.font.Font(None, 40)  # Teksti font ja suurus
        self.about = False  # Muutuja mängu "About" ekraani jaoks
        self.game_over = True  # Muutuja, mis näitab, kas mäng on läbi või mitte
        self.score = 0  # Mängija skoor
        self.high_score = self.load_high_score()  # Kõrgeim skoor, laetakse failist
        self.start_time = 0  # Algusaeg mängu ajamõõtmiseks
        self.elapsed_time = 0  # Möödunud aeg sekundites
        self.previous_score, self.previous_time = self.load_previous_stats()  # Eelmine skoor ja aeg
        self.menu = Menu(("Alusta", "Eelmine Mäng", "Lahku"), self)
        self.player = Player(32, 128, "player.png")  # Mängija objekt
        self.horizontal_blocks = pygame.sprite.Group()  # Grupp horisontaalsete takistuste jaoks
        self.vertical_blocks = pygame.sprite.Group()  # Grupp vertikaalsete takistuste jaoks
        self.dots_group = pygame.sprite.Group()  # Grupp punktide (punktide) jaoks
        self.enemies = pygame.sprite.Group()  # Grupp vaenlaste jaoks

        # Keskkonna ja punktide genereerimine
        for i, row in enumerate(enviroment()):
            for j, item in enumerate(row):
                if item == 1:
                    self.horizontal_blocks.add(Block(j * 32 + 8, i * 32 + 8, BLACK, 16, 16))
                elif item == 2:
                    self.vertical_blocks.add(Block(j * 32 + 8, i * 32 + 8, BLACK, 16, 16))
                if item != 0:
                    self.dots_group.add(Ellipse(j * 32 + 12, i * 32 + 12, WHITE, 8, 8))

        # Vaenlaste (Slime objektide) loomine
        enemy_positions = [(288, 96, 0, 2), (288, 320, 0, -2), (544, 128, 0, 2), (32, 224, 0, 2),
                           (160, 64, 2, 0), (448, 64, -2, 0), (640, 448, 2, 0), (448, 320, 2, 0)]
        for pos in enemy_positions:
            image_file = random.choice(["slime.png", "slime2.png", "slime3.png"])
            self.enemies.add(Slime(*pos, image_file))

        # Helifailide initsialiseerimine
        self.pacman_sound = pygame.mixer.Sound("pacman_sound.ogg")
        self.game_over_sound = pygame.mixer.Sound("game_over_sound.ogg")
        
    def load_previous_stats(self):
        try:
            with open("time_score.txt", "r") as file:
                score = int(file.readline().strip())
                time = int(file.readline().strip())
                return score, time
        except FileNotFoundError:
            return 0, 0  # Kui faili ei leita, tagasta vaikimisi väärtused
        except Exception as e:
            print(f"Viga eelnevate statistika laadimisel: {e}")
            return 0, 0  # Muu viga korral tagasta vaikimisi väärtused

    def load_high_score(self):
        try:
            with open("high_score.txt", "r") as file:
                return int(file.read().strip())  # Tagasta kõrgeim skoor failist
        except FileNotFoundError:
            return 0  # Kui faili ei leita, tagasta 0
        except Exception as e:
            print(f"Viga kõrgeima skoori laadimisel: {e}")
            return 0  # Muu viga korral tagasta 0

    def save_high_score(self):
        try:
            with open("high_score.txt", "w") as file:
                file.write(str(self.high_score))  # Salvesta kõrgeim skoor faili
        except Exception as e:
            print(f"Viga kõrgeima skoori salvestamisel: {e}")
            
    def save_previous_stats(self):
        try:
            with open("time_score.txt", "w") as file:
                file.write(str(self.score) + "\n")
                file.write(str(self.elapsed_time) + "\n")
        except Exception as e:
            print(f"Viga eelnevate statistika salvestamisel: {e}")

    def process_events(self):
        for event in pygame.event.get():  # Loome sündmuste töötlemise tsükli
            if event.type == pygame.QUIT:  # Kui kasutaja sulgeb mänguakna
                return True  # Tagasta True, et lõpetada mängu jooks
            self.menu.event_handler(event)  # Menüü sündmuste töötlemine
            if event.type == pygame.KEYDOWN:  # Kui vajutatakse klahvi
                if event.key == pygame.K_RETURN:  # Kui vajutatakse Enter klahvi
                    if self.game_over and not self.about:  # Kui mäng on läbi ja mitte "About" ekraanil
                        if self.menu.state == 0:  # Kui menüü olek on 0 (Start)
                            self.__init__()  # Alusta uut mängu
                            self.game_over = False  # Mäng ei ole enam läbi
                            self.start_time = pygame.time.get_ticks()  # Alusta ajamõõtmist
                        elif self.menu.state == 1:  # Kui menüü olek on 1 (About)
                            self.about = True  # Näita "About" ekraani
                        elif self.menu.state == 2:  # Kui menüü olek on 2 (Exit)
                            return True  # Tagasta True, et lõpetada mängu jooks

                elif event.key == pygame.K_RIGHT:  # Kui vajutatakse parem nool
                    self.player.move_right()  # Mängija liigub paremale

                elif event.key == pygame.K_LEFT:  # Kui vajutatakse vasak nool
                    self.player.move_left()  # Mängija liigub vasakule

                elif event.key == pygame.K_UP:  # Kui vajutatakse ülemine nool
                    self.player.move_up()  # Mängija liigub üles

                elif event.key == pygame.K_DOWN:  # Kui vajutatakse alumine nool
                    self.player.move_down()  # Mängija liigub alla

                elif event.key == pygame.K_ESCAPE:  # Kui vajutatakse Escape klahvi
                    self.game_over = True  # Mäng on läbi
                    self.about = False  # "About" ekraan on suletud

            elif event.type == pygame.KEYUP:  # Kui klahvi vabastatakse
                if event.key == pygame.K_RIGHT:
                    self.player.stop_move_right()
                elif event.key == pygame.K_LEFT:
                    self.player.stop_move_left()
                elif event.key == pygame.K_UP:
                    self.player.stop_move_up()
                elif event.key == pygame.K_DOWN:
                    self.player.stop_move_down()

            elif event.type == pygame.MOUSEBUTTONDOWN:  # Kui vajutatakse hiire nuppu
                self.player.explosion = True  # Käivitatakse mängija plahvatus animatsioon

        return False  # Tagasta False, et mäng ei lõpe

    def run_logic(self):
        block_hit_list = []
        
        # Kontrollime, kas mäng on lõppenud
        if not self.game_over:
            # Arvutame möödunud aja sekundites alates mängu algusest
            self.elapsed_time = (pygame.time.get_ticks() - self.start_time) // 1000
            # Uuendame mängija asukohta ja kollisioonide kontrolli punktidega
            self.player.update(self.horizontal_blocks, self.vertical_blocks)
            # Kontrollime, kas mängija puutus kokku punktiga (dot)
            block_hit_list = pygame.sprite.spritecollide(self.player, self.dots_group, True)
        
        # Kui punktiga puututi kokku, mängime heli ja suurendame skoori
        if block_hit_list:
            self.pacman_sound.play()
            self.score += 10
            
        # Kontrollime, kas mängija puutus kokku vaenlasega
        block_hit_list = pygame.sprite.spritecollide(self.player, self.enemies, True)
        if block_hit_list:
            # Käivitame mängija plahvatuse animatsiooni ja mängime mängu lõpu heli
            self.player.explosion = True
            self.game_over_sound.play()
            self.game_over = True  # Mäng on läbi
            self.save_previous_stats()  # Salvestame eelnevad statistikad

        # Uuendame vaenlasi vastavalt mängu loogikale
        self.enemies.update(self.horizontal_blocks, self.vertical_blocks)

        # Kui mängija skoor on suurem kui kõrgeim salvestatud skoor, uuendame kõrgeimat skoori
        if self.score > self.high_score:
            self.high_score = self.score
            self.save_high_score()

        # Pärast mängu loogika töötlemist saame turvaliselt kasutada block_hit_list'i
        if block_hit_list:
            # Töötle edasist loogikat, mis on seotud block_hit_list'iga
            pass

    def save_high_score(self):
        # Salvestame kõrgeima skoori ja möödunud aja faili "time_score.txt"
        with open("time_score.txt", "w") as file:
            file.write(str(self.score) + "\n")
            file.write(str(self.elapsed_time) + "\n")

    def display_frame(self, screen):
        screen.fill(BLACK)  # Tühjendame ekraani mustaks värviks

        if self.game_over:
            if self.about:
                # Kui mäng on läbi ja kuvatakse "About" ekraan
                self.display_message(screen, "Üllatus!")
            else:
                # Kui mäng on läbi ja kuvatakse menüü
                self.menu.display_frame(screen)
        else:
            # Kui mäng käib, kuvame mänguelemendid ja statistika
            self.horizontal_blocks.draw(screen)
            self.vertical_blocks.draw(screen)
            draw_enviroment(screen)  # Funktsioon, mis kuvab keskkonna
            self.dots_group.draw(screen)
            self.enemies.draw(screen)
            screen.blit(self.player.image, self.player.rect)
            text = self.font.render("Skoor: " + str(self.score), True, GREEN)
            screen.blit(text, (350, 140))
            high_score_text = self.font.render("High Skoor: " + str(self.high_score), True, GREEN)
            screen.blit(high_score_text, (270, 250))
            timer_text = self.font.render("Aeg: " + str(self.elapsed_time) + "s", True, GREEN)
            screen.blit(timer_text, (350, 380))

        pygame.display.flip()  # Värskendame ekraani sisu

    def display_message(self, screen, message, color=(255, 0, 0)):
        # Kuvame sõnumi ekraanil
        label = self.font.render(message, True, color)
        width = label.get_width()
        height = label.get_height()
        posX = (SCREEN_WIDTH / 2) - (width / 2)
        posY = (SCREEN_HEIGHT / 2) - (height / 2)
        screen.blit(label, (posX, posY))

class Menu(object):
    state = 0

    def __init__(self, items, game_instance, font_color=(255, 255, 255), select_color=(255, 0, 0), ttf_font=None, font_size=60):
        # Menüü objekti initsialiseerimine
        self.font_color = font_color
        self.select_color = select_color
        self.items = items
        self.font = pygame.font.Font(ttf_font, font_size)
        self.game_instance = game_instance  # Viide Game klassi objektile

    def display_frame(self, screen):
        screen.fill(BLACK)  # Tühjendame ekraani mustaks värviks

        # Kuvame menüüd
        for index, item in enumerate(self.items):
            if self.state == index:
                label = self.font.render(item, True, self.select_color)
            else:
                label = self.font.render(item, True, self.font_color)

            width = label.get_width()
            height = label.get_height()

            posX = (SCREEN_WIDTH / 2) - (width / 2)
            t_h = len(self.items) * height
            posY = (SCREEN_HEIGHT / 2) - (t_h / 2) + (index * height)

            screen.blit(label, (posX, posY))

            if self.state == 1:  # Kuvame eelneva mängu statistikat menüü valiku "Previous Game" korral
                previous_stats_label = self.font.render(f"Skoor: {self.game_instance.previous_score} | Aeg mängitud: {self.game_instance.previous_time}s", True, WHITE)
                screen.blit(previous_stats_label, (SCREEN_WIDTH / 2 - previous_stats_label.get_width() / 2, SCREEN_HEIGHT / 2 + t_h / 2 + 20))

    def event_handler(self, event):
        # Käsitseme sündmusi
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                if self.state > 0:
                    self.state -= 1
            elif event.key == pygame.K_DOWN:
                if self.state < len(self.items) - 1:
                    self.state += 1