#!/usr/bin/env python
# -*- coding: utf-8 -*-
import pygame  # Impordi pygame moodul
from game import Game  # Impordi Game klass mängu moodulist

SCREEN_WIDTH = 800  # Ekraani laius
SCREEN_HEIGHT = 576  # Ekraani kõrgus

def main():
    # Initsialiseeri kõik imporditud pygame moodulid
    pygame.init()
    # Määra ekraani laius ja kõrgus [laius, kõrgus]
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    # Määra praegune akna pealkiri
    pygame.display.set_caption("PACMAN")
    # Tsükkel, kuni kasutaja klikib sulgemisnuppu
    done = False
    # Kasutatakse ekraani värskendamise kiiruse haldamiseks
    clock = pygame.time.Clock()
    # Loo mängu objekt
    game = Game()

    pygame.mixer.music.load("muusika.mp3")  # Lae muusika fail
    pygame.mixer.music.play(-1)  # -1 tsükliliselt lõpmatult mängimiseks

    # -------- Peamine programmitsükkel -----------
    while not done:
        # --- Töötle sündmusi (klahvivajutused, hiireklõpsud jne)
        done = game.process_events()
        # --- Mängu loogika peaks siin olema
        game.run_logic()
        # --- Joonista praegune kaader
        game.display_frame(screen)
        # --- Piira kiirust 30 kaadrini sekundis
        clock.tick(30)
        # tkMessageBox.showinfo("GAME OVER!","Final Score = "+(str)(GAME.score))

    # Sule aken ja lõpeta.
    # Kui unustad selle rea, jääb programm 'hängima'
    # väljumisel, kui käivitada IDLE-st.
    pygame.quit()

# Kontrolli, kas see fail käivitati otse, mitte ei imporditud
if __name__ == '__main__':
    main()  # Käivita peamine funktsioon