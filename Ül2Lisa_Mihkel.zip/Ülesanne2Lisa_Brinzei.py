# Mihkel Brinzei
import pygame

pygame.init()
#ekraani seaded
screen=pygame.display.set_mode([640,480]) # Ekraani suurus
pygame.display.set_caption("Ülesanne 2 Lisa") # Teksti nimi
screen.fill([204, 255, 204]) # Täidab ekraani värviga

#Lisame pildid
bg = pygame.image.load("bg_shop.jpg") #impordib pildi faili - taust
bg = pygame.transform.scale(bg, [640, 480]) # muudab pildi dimensioone
screen.blit(bg,[0,0]) # lõpuks näitab ekraanil pilti

mook = pygame.image.load("mook.png") #impordib pildi faili - mõõk
mook = pygame.transform.scale(mook, [125, 100]) # muudab pildi dimensioone
screen.blit(mook,[0,125]) # lõpuks näitab ekraanil pilti

seller = pygame.image.load("seller.png") #impordib pildi faili - müüja
seller = pygame.transform.scale(seller, [250, 300]) # muudab pildi dimensioone
screen.blit(seller,[105,160]) # lõpuks näitab ekraanil pilti

kook = pygame.image.load("kook.png") #impordib pildi faili - kook
kook = pygame.transform.scale(kook, [128, 128]) # muudab pildi dimensioone
screen.blit(kook,[450,170]) # lõpuks näitab ekraanil pilt

bubble = pygame.image.load("chat.png") #impordib pildi faili - teksti mull
bubble = pygame.transform.scale(bubble, [250, 200]) # muudab pildi dimensioone
screen.blit(bubble,[250,80]) # lõpuks näitab ekraanil pilti

font = pygame.font.Font(pygame.font.match_font('arial'), 22) # Lisame fonti ja suuruse
text = font.render("Tere, olen Mihkel Brinzei", True, [255,255,255]) # Valitud fontist paneme teksti mida tahame ja värvi
screen.blit(text, [280,155]) # Kuvab meie tehtud teksti

VIKK100 = pygame.image.load("vikk.png") #impordib pildi faili - vikk logo
VIKK100 = pygame.transform.scale(VIKK100, [280, 35]) # muudab pildi dimensioone
screen.blit(VIKK100,[0,0]) # lõpuks näitab ekraanil pilti

font = pygame.font.Font(pygame.font.match_font('Helvetica'), 22) # Lisame fonti ja suuruse
font.set_italic(True)
text = font.render("TULEVIK 2050", True, [255,255,255]) # Valitud fontist paneme teksti mida tahame ja värvi
screen.blit(text, [285,10]) # Kuvab meie tehtud teksti


pygame.display.flip() # Uuendab ekraani, et näidata joonistust

running = True
while running:
    for event in pygame.event.get():
        if event.type ==  pygame.QUIT:
            pygame.quit() # sulgeb akna kui vajutada ristist